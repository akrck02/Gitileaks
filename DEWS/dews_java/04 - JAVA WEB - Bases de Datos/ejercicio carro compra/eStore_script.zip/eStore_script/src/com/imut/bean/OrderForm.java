package com.imut.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

public class OrderForm implements Serializable {
    private int id;
    private Customer customer;
    private Double cost;
    private Date orderDate;
    private Set orderLines = new HashSet();
    
    
    
    public OrderForm() {
    }
    
    
    public OrderForm(int id, Customer customer, Double cost, Date orderDate,
            Set orderLines) {
        super();
        this.id = id;
        this.customer = customer;
        this.cost = cost;
        this.orderDate = orderDate;
        this.orderLines = orderLines;
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public Double getCost() {
        return cost;
    }
    public void setCost(Double cost) {
        this.cost = cost;
    }
    public Date getOrderDate() {
        return orderDate;
    }
    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
    public Set getOrderLines() {
        return orderLines;
    }
    public void setOrderLines(Set orderLines) {
        this.orderLines = orderLines;
    }
    
    
}
