package com.imut.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.bean.Customer;
import com.imut.bean.OrderForm;
import com.imut.bean.OrderLine;
import com.imut.bean.ShoppingCart;
import com.imut.common.ConnectionFactory;
import com.imut.common.HL;
import com.imut.dao.customer.CustomerDaoImpl;
import com.imut.dao.order.OrderDaoImpl;

public class ConfirmServlet extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to get.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

       process(request, response);
    }

    /**
     * The doPost method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to post.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        process(request, response);
    }
    public void process(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
        String zip = request.getParameter("zip");
        String address = request.getParameter("address");
        String tel = request.getParameter("telephone");
        String email = request.getParameter("email");
        HttpSession session = request.getSession();
        Customer c = (Customer) session.getAttribute("customer");
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        
        c.setZip(zip);
        c.setAddress(address);
        c.setTelephone(tel);
        c.setEmail(email);
        double cost = cart.getCost();
        
        Connection conn = ConnectionFactory.getConnection();
        OrderForm order = new OrderForm();
        order.setCost(cost);
        order.setCustomer(c);
        order.setId(HL.getOID(conn));
        order.setOrderDate(new Date(new java.util.Date().getTime()));
        OrderDaoImpl oDao = new OrderDaoImpl(conn);
        CustomerDaoImpl cDao = new CustomerDaoImpl(conn);
        oDao.saveOrder(order);
        cDao.updateCustomer(c);
        
        Collection<OrderLine> oLines = cart.getOrderLines();
        Set<OrderLine> set = new HashSet<OrderLine>(oLines);
        order.setOrderLines(set);
        request.setAttribute("order", order);
        for(OrderLine line : oLines){
            line.setId(HL.getOID(conn));
            line.setOrderForm(order);
            oDao.saveOrderLine(line);
        }
        
        request.getRequestDispatcher("/confirm.jsp").
        forward(request, response);
    }

}
