package com.imut.dao.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.imut.bean.Book;
import com.imut.bean.Customer;
import com.imut.bean.OrderForm;
import com.imut.bean.OrderLine;
import com.imut.common.DBUtil;

public class OrderDaoImpl {
    
    private Connection conn;
    public OrderDaoImpl(Connection conn){
        this.conn = conn;
    }
    public Map findAllBook(){
        Statement  stmt = null;
        ResultSet rs = null;
        Map books = new TreeMap();
        Book book = null;
        try{
            String sql = "select id,name,price from book";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while(rs.next()){
                book = new Book(rs.getInt(1),rs.getString(2),rs.getDouble(3));
                books.put(new Integer(book.getId()), book);
            }
        }catch (Exception e) {
            // TODO: handle exception
        }finally{
            DBUtil.close(stmt, rs);
        }
        return books;
    }
    public void saveOrder(OrderForm order){
        PreparedStatement pstmt = null;
        try {
            String sql = "insert into orderform values (?,?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, order.getId());
            pstmt.setDouble(2, order.getCost());
            pstmt.setDate(3, order.getOrderDate());
            pstmt.setInt(4, order.getCustomer().getId());
            pstmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            DBUtil.close(pstmt);
        }
    }
    
    public void saveOrderLine(OrderLine oLine){
        PreparedStatement pstmt = null;
        try {
            String sql = "insert into orderline values (?,?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, oLine.getId());
            pstmt.setInt(2, oLine.getNum());
            pstmt.setInt(3, oLine.getOrderForm().getId());
            pstmt.setInt(4, oLine.getBook().getId());
            
            pstmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            DBUtil.close(pstmt);
        }
    }
    
    public Map<Integer, OrderForm> findAllOrder(Customer cus){
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Map<Integer,OrderForm> orders = new TreeMap<Integer, OrderForm>();
        try {
            String sql = 
                "select id,cost,orderdate,customerid from orderform " +
                " where customerid=?";
            pstmt =conn.prepareStatement(sql);
            pstmt.setInt(1, cus.getId());
            rs = pstmt.executeQuery();
            OrderForm order = null;
            while(rs.next()){
                int id = rs.getInt(1);
                order = new OrderForm();
                order.setId(id);
                order.setCost(rs.getDouble(2));
                order.setOrderDate(rs.getDate(3));
                order.setCustomer(cus);
                order.setOrderLines(findOrderLineByOrder(order));
                orders.put(new Integer(id), order);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            DBUtil.close(pstmt, rs);
        }
        return orders;
    }
    
    public Set<OrderLine> findOrderLineByOrder(OrderForm order){
        Set<OrderLine> lines = new HashSet<OrderLine>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String sql = "select id,num,orderid,bookid from " +
            		" orderline where orderid=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, order.getId());
            rs = pstmt.executeQuery();
            OrderLine ol = null;
            Book book = null;
            while(rs.next()){
                book = findBookById(rs.getInt(4));
                ol = new OrderLine(rs.getInt(1),rs.getInt(2),book,order);
                lines.add(ol);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            DBUtil.close(pstmt, rs);
        }
        return lines;
    }
    
    public Book findBookById(int bookid){
        Book book = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String sql = "select id,name,price from " +
                    " book where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bookid);
            rs = pstmt.executeQuery();
            while(rs.next()){
                book = new Book
                (rs.getInt(1),rs.getString(2),rs.getDouble(3));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            DBUtil.close(pstmt, rs);
        }
        return book;
    }
}
