package com.imut.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Book implements Serializable{
    private int id;
    private String name;
    private double price;
    private Set orderLines= new HashSet();
    
    
    public Book() {
    }
    public Book(int id, String name, double price, Set orderLines) {
        super();
        this.id = id;
        this.name = name;
        this.price = price;
        this.orderLines = orderLines;
    }
    public Book(int id, String name, double price) {
        super();
        this.id = id;
        this.name = name;
        this.price = price;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public Set getOrderLines() {
        return orderLines;
    }
    public void setOrderLines(Set orderLines) {
        this.orderLines = orderLines;
    }
    
    
}
