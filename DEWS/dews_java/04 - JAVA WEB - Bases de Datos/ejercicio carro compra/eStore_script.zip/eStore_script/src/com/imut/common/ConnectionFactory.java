package com.imut.common;

import java.sql.*;
public class ConnectionFactory {
	private static String driver = 
		"oracle.jdbc.driver.OracleDriver";
	private static String url = "jdbc:oracle:thin:@219.225.211.130:1521:XE";
	private static String userName = "team11";
	private static String passwd = "team11";
	
	public static Connection getConnection(){
		Connection conn = null;
		try{
			Class.forName(driver);
			conn = DriverManager.getConnection
			(url,userName,passwd);
		}catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
}
