package com.imut.dao.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.imut.bean.Customer;
import com.imut.common.DBUtil;

public class CustomerDaoImpl {
    private Connection conn = null;
    public CustomerDaoImpl(Connection conn){
        this.conn = conn;
    }
    
    // ע���û�
    public boolean saveCustomer(Customer customer){
        boolean isOk = false;
        PreparedStatement pstmt = null;
        try{
            boolean isIn = findCustomer(customer.getName());
            if(isIn){
                isOk = false;
            }else{
                String sql = 
                    "insert into customer values (?,?,?,?,?,?,?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, customer.getId());
                pstmt.setString(2, customer.getName());
                pstmt.setString(3, customer.getPassword());
                pstmt.setString(4, customer.getZip());
                pstmt.setString(5, customer.getAddress());
                pstmt.setString(6, customer.getTelephone());
                pstmt.setString(7, customer.getEmail());
                pstmt.execute();  
                isOk = true;
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally{
            
        }
        return isOk;
    }
    
    // ��½
    public Customer findCustomer(String name,String passwd){
        String sql = "select id,name,password,zip,address,telephone,email " +
        		" from customer where name=? and password=?";
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Customer c = null;
        try{
            pstmt= conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, passwd);
            rs = pstmt.executeQuery();
            while(rs.next()){
                c= new Customer();
                c.setId(rs.getInt(1));
                c.setName(rs.getString(2));
                c.setPassword(rs.getString(3));
                c.setZip(rs.getString(4));
                c.setAddress(rs.getString(5));
                c.setTelephone(rs.getString(6));
                c.setEmail(rs.getString(7));
            }
       }catch(Exception e){
        e.printStackTrace();   
       }finally{
           DBUtil.close(pstmt, rs);
       }
       return c;
    }
    
    public boolean findCustomer(String name){
        String sql = "select id " +
                " from customer where name=?";
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int id = 0;
        try{
            pstmt= conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while(rs.next()){
                id = rs.getInt(1);            }
       }catch(Exception e){
        e.printStackTrace();   
       }finally{
           DBUtil.close(pstmt, rs);
       }
       if(id==0)
           return false;
       return true;
    }
    
    // �����û���Ϣ 
    public boolean updateCustomer(Customer customer){
        boolean isOk = false;
        PreparedStatement pstmt = null;
        try{
          
            String sql = 
                "update customer set zip=?,address=?,telephone=?,email=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, customer.getZip());
            pstmt.setString(2, customer.getAddress());
            pstmt.setString(3, customer.getTelephone());
            pstmt.setString(4, customer.getEmail());
            pstmt.executeUpdate();  
            isOk = true;
            
        }catch (Exception e) {
            e.printStackTrace();
        }finally{
            
        }
        return isOk;
    }
}
