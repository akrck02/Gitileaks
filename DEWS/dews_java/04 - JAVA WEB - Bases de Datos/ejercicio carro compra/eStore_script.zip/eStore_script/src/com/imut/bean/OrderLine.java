package com.imut.bean;

import java.io.Serializable;

public class OrderLine implements Serializable{
    private int id;
    private int num;
    private Book book;
    private OrderForm orderForm;
    
    
    public OrderLine(int id, int num, Book book, OrderForm orderForm) {
        super();
        this.id = id;
        this.num = num;
        this.book = book;
        this.orderForm = orderForm;
    }
    public OrderLine() {
    }
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getNum() {
        return num;
    }
    public void setNum(int num) {
        this.num = num;
    }
    public Book getBook() {
        return book;
    }
    public void setBook(Book book) {
        this.book = book;
    }
    public OrderForm getOrderForm() {
        return orderForm;
    }
    public void setOrderForm(OrderForm orderForm) {
        this.orderForm = orderForm;
    }
    
    
}
