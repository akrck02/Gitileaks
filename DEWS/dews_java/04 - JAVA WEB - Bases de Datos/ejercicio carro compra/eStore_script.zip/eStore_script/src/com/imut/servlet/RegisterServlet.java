package com.imut.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.imut.bean.Customer;
import com.imut.common.ConnectionFactory;
import com.imut.common.HL;
import com.imut.dao.customer.CustomerDaoImpl;

public class RegisterServlet extends HttpServlet {

    /**
     * The doGet method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to get.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

      process(request, response);
    }

    /**
     * The doPost method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to post.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        process(request, response);
    }

    public void process(HttpServletRequest request,HttpServletResponse response){
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        Connection conn = ConnectionFactory.getConnection();
        int id = HL.getOID(conn);
        String name = request.getParameter("name");
        String passwd = request.getParameter("password");
        String zip = request.getParameter("zip");
        String address = request.getParameter("address");
        String telephone = request.getParameter("telephone");
        String email = request.getParameter("email");
        
        Customer c = new Customer();
        c.setId(id);
        c.setName(name);
        c.setPassword(passwd);
        c.setZip(zip);
        c.setAddress(address);
        c.setTelephone(telephone);
        c.setEmail(email);
        
        CustomerDaoImpl dao = new CustomerDaoImpl(conn);
        boolean isOk = dao.saveCustomer(c);
        if(isOk){
      
            try {
                request.getSession().setAttribute("message", "ע��ɹ���");
                response.sendRedirect(request.getContextPath()+"/login.jsp");
                //request.getRequestDispatcher("login.jsp").forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            request.getSession().setAttribute("message", "ע��ʧ�ܣ�");
            try {
                request.getRequestDispatcher("/register.jsp").
                forward(request, response);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
